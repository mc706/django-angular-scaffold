django-angular-scaffold
=======================

set of django commands to scaffold a django-angular project
